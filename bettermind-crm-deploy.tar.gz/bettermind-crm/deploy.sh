#!/usr/bin/env bash
set -euo pipefail

# ============================================================
# BetterMind CRM — Cloud Run Deploy Script
# ============================================================
# Usage: ./deploy.sh [PROJECT_ID] [REGION]
# Example: ./deploy.sh bettermind-prod us-west1
# ============================================================

PROJECT_ID="${1:-$(gcloud config get-value project 2>/dev/null)}"
REGION="${2:-us-west1}"
SERVICE_NAME="bettermind-crm"

if [ -z "$PROJECT_ID" ]; then
  echo "❌ No GCP project set. Usage: ./deploy.sh PROJECT_ID [REGION]"
  echo "   Or run: gcloud config set project YOUR_PROJECT_ID"
  exit 1
fi

echo ""
echo "🧠 BetterMind CRM — Deploying to Cloud Run"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Project:  $PROJECT_ID"
echo "  Region:   $REGION"
echo "  Service:  $SERVICE_NAME"
echo ""

# Set project
gcloud config set project "$PROJECT_ID"

# Enable required APIs
echo "📦 Enabling required APIs..."
gcloud services enable \
  run.googleapis.com \
  cloudbuild.googleapis.com \
  artifactregistry.googleapis.com \
  --quiet

# Initialize the database if it doesn't exist
if [ ! -f "backend/bettermind_crm.db" ]; then
  echo "🗄️  Initializing database..."
  cd backend
  pip install -q -r requirements.txt 2>/dev/null || pip3 install -q -r requirements.txt 2>/dev/null
  python3 database.py
  cd ..
fi

# Deploy to Cloud Run (source-based deploy — no local Docker needed)
echo ""
echo "🚀 Deploying to Cloud Run..."
echo "   (This uses Cloud Build — no local Docker required)"
echo ""

gcloud run deploy "$SERVICE_NAME" \
  --source . \
  --region "$REGION" \
  --allow-unauthenticated \
  --memory 512Mi \
  --cpu 1 \
  --min-instances 0 \
  --max-instances 3 \
  --port 8080 \
  --set-env-vars "DATABASE_PATH=/app/backend/bettermind_crm.db" \
  --quiet

# Get the URL
SERVICE_URL=$(gcloud run services describe "$SERVICE_NAME" \
  --region "$REGION" \
  --format='value(status.url)')

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "✅ BetterMind CRM deployed successfully!"
echo ""
echo "   🌐 URL: $SERVICE_URL"
echo ""
echo "   API:  $SERVICE_URL/api/contacts"
echo "   Docs: $SERVICE_URL/docs"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
