"""
BetterMind CRM — FastAPI Backend
Serves REST API + static React frontend
"""
import os
import sqlite3
from contextlib import contextmanager
from datetime import datetime
from typing import Optional

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from database import DB_PATH, get_connection, init_schema, seed_data

app = FastAPI(
    title="BetterMind CRM API",
    description="Contact management, investor pipeline, and program tracking for BetterMind.Space",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@contextmanager
def db():
    conn = get_connection()
    try:
        yield conn
    finally:
        conn.close()


def row_to_dict(row):
    if row is None:
        return None
    return dict(row)


def rows_to_list(rows):
    return [dict(r) for r in rows]


# ==================== STARTUP ====================

@app.on_event("startup")
def startup():
    conn = get_connection()
    init_schema(conn)
    seed_data(conn)
    conn.close()


# ==================== MODELS ====================

class ContactCreate(BaseModel):
    first_name: str
    last_name: Optional[str] = None
    email: Optional[str] = None
    email_secondary: Optional[str] = None
    phone: Optional[str] = None
    phone_secondary: Optional[str] = None
    linkedin_url: Optional[str] = None
    organization_id: Optional[int] = None
    title: Optional[str] = None
    category: str
    subcategory: Optional[str] = None
    status: str
    tier: Optional[int] = None
    last_contact_date: Optional[str] = None
    next_action: Optional[str] = None
    next_action_date: Optional[str] = None
    notes: Optional[str] = None


class ContactUpdate(BaseModel):
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    linkedin_url: Optional[str] = None
    organization_id: Optional[int] = None
    title: Optional[str] = None
    category: Optional[str] = None
    subcategory: Optional[str] = None
    status: Optional[str] = None
    tier: Optional[int] = None
    last_contact_date: Optional[str] = None
    next_action: Optional[str] = None
    next_action_date: Optional[str] = None
    notes: Optional[str] = None


class InteractionCreate(BaseModel):
    contact_id: int
    type: str
    channel: Optional[str] = None
    subject: Optional[str] = None
    summary: Optional[str] = None
    date: str


class DealCreate(BaseModel):
    contact_id: Optional[int] = None
    organization_id: Optional[int] = None
    deal_name: str
    stage: str
    amount: Optional[str] = None
    probability: Optional[int] = None
    notes: Optional[str] = None


# ==================== CONTACTS ====================

@app.get("/api/contacts")
def list_contacts(
    category: Optional[str] = None,
    status: Optional[str] = None,
    tier: Optional[int] = None,
    search: Optional[str] = None,
    limit: int = Query(default=200, le=500),
    offset: int = 0,
):
    with db() as conn:
        query = """
            SELECT c.*, o.name as organization_name
            FROM contacts c
            LEFT JOIN organizations o ON c.organization_id = o.id
            WHERE 1=1
        """
        params = []
        if category:
            query += " AND c.category = ?"
            params.append(category)
        if status:
            query += " AND c.status = ?"
            params.append(status)
        if tier:
            query += " AND c.tier = ?"
            params.append(tier)
        if search:
            query += """ AND (c.first_name || ' ' || COALESCE(c.last_name, '') LIKE ?
                OR c.email LIKE ? OR c.title LIKE ? OR c.notes LIKE ?
                OR o.name LIKE ?)"""
            s = f"%{search}%"
            params.extend([s, s, s, s, s])
        query += " ORDER BY c.tier ASC, c.last_contact_date DESC LIMIT ? OFFSET ?"
        params.extend([limit, offset])
        return rows_to_list(conn.execute(query, params).fetchall())


@app.get("/api/contacts/{contact_id}")
def get_contact(contact_id: int):
    with db() as conn:
        row = conn.execute("""
            SELECT c.*, o.name as organization_name
            FROM contacts c
            LEFT JOIN organizations o ON c.organization_id = o.id
            WHERE c.id = ?
        """, (contact_id,)).fetchone()
        if not row:
            raise HTTPException(404, "Contact not found")
        contact = row_to_dict(row)
        contact["interactions"] = rows_to_list(
            conn.execute("SELECT * FROM interactions WHERE contact_id = ? ORDER BY date DESC", (contact_id,)).fetchall()
        )
        contact["deals"] = rows_to_list(
            conn.execute("""SELECT d.*, o.name as org_name FROM deals d
                LEFT JOIN organizations o ON d.organization_id = o.id
                WHERE d.contact_id = ?""", (contact_id,)).fetchall()
        )
        return contact


@app.post("/api/contacts", status_code=201)
def create_contact(data: ContactCreate):
    with db() as conn:
        c = conn.execute("""
            INSERT INTO contacts (first_name,last_name,email,email_secondary,phone,phone_secondary,
                linkedin_url,organization_id,title,category,subcategory,status,tier,
                last_contact_date,next_action,next_action_date,notes)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (data.first_name, data.last_name, data.email, data.email_secondary,
              data.phone, data.phone_secondary, data.linkedin_url, data.organization_id,
              data.title, data.category, data.subcategory, data.status, data.tier,
              data.last_contact_date, data.next_action, data.next_action_date, data.notes))
        conn.commit()
        return {"id": c.lastrowid}


@app.put("/api/contacts/{contact_id}")
def update_contact(contact_id: int, data: ContactUpdate):
    with db() as conn:
        existing = conn.execute("SELECT * FROM contacts WHERE id = ?", (contact_id,)).fetchone()
        if not existing:
            raise HTTPException(404, "Contact not found")
        updates = {k: v for k, v in data.dict().items() if v is not None}
        if not updates:
            return row_to_dict(existing)
        updates["updated_at"] = datetime.now().isoformat()
        set_clause = ", ".join(f"{k} = ?" for k in updates.keys())
        conn.execute(f"UPDATE contacts SET {set_clause} WHERE id = ?",
                     list(updates.values()) + [contact_id])
        conn.commit()
        return row_to_dict(conn.execute("SELECT * FROM contacts WHERE id = ?", (contact_id,)).fetchone())


@app.delete("/api/contacts/{contact_id}")
def delete_contact(contact_id: int):
    with db() as conn:
        conn.execute("DELETE FROM contacts WHERE id = ?", (contact_id,))
        conn.commit()
        return {"deleted": contact_id}


# ==================== ORGANIZATIONS ====================

@app.get("/api/organizations")
def list_organizations():
    with db() as conn:
        return rows_to_list(conn.execute("SELECT * FROM organizations ORDER BY name").fetchall())


@app.get("/api/organizations/{org_id}")
def get_organization(org_id: int):
    with db() as conn:
        org = conn.execute("SELECT * FROM organizations WHERE id = ?", (org_id,)).fetchone()
        if not org:
            raise HTTPException(404, "Organization not found")
        result = row_to_dict(org)
        result["contacts"] = rows_to_list(
            conn.execute("SELECT * FROM contacts WHERE organization_id = ? ORDER BY category, status", (org_id,)).fetchall()
        )
        return result


# ==================== INTERACTIONS ====================

@app.get("/api/interactions")
def list_interactions(contact_id: Optional[int] = None, limit: int = 50):
    with db() as conn:
        if contact_id:
            return rows_to_list(conn.execute(
                "SELECT * FROM interactions WHERE contact_id = ? ORDER BY date DESC LIMIT ?",
                (contact_id, limit)).fetchall())
        return rows_to_list(conn.execute(
            """SELECT i.*, c.first_name || ' ' || COALESCE(c.last_name, '') as contact_name
            FROM interactions i JOIN contacts c ON i.contact_id = c.id
            ORDER BY i.date DESC LIMIT ?""", (limit,)).fetchall())


@app.post("/api/interactions", status_code=201)
def create_interaction(data: InteractionCreate):
    with db() as conn:
        c = conn.execute("""INSERT INTO interactions (contact_id,type,channel,subject,summary,date)
            VALUES (?,?,?,?,?,?)""",
            (data.contact_id, data.type, data.channel, data.subject, data.summary, data.date))
        conn.execute("UPDATE contacts SET last_contact_date = ?, updated_at = ? WHERE id = ?",
                     (data.date, datetime.now().isoformat(), data.contact_id))
        conn.commit()
        return {"id": c.lastrowid}


# ==================== DEALS ====================

@app.get("/api/deals")
def list_deals():
    with db() as conn:
        return rows_to_list(conn.execute("""
            SELECT d.*, c.first_name || ' ' || COALESCE(c.last_name, '') as contact_name,
                   o.name as org_name
            FROM deals d
            LEFT JOIN contacts c ON d.contact_id = c.id
            LEFT JOIN organizations o ON d.organization_id = o.id
            ORDER BY d.probability DESC
        """).fetchall())


@app.post("/api/deals", status_code=201)
def create_deal(data: DealCreate):
    with db() as conn:
        c = conn.execute("""INSERT INTO deals (contact_id,organization_id,deal_name,stage,amount,probability,notes)
            VALUES (?,?,?,?,?,?,?)""",
            (data.contact_id, data.organization_id, data.deal_name, data.stage,
             data.amount, data.probability, data.notes))
        conn.commit()
        return {"id": c.lastrowid}


# ==================== PROGRAMS ====================

@app.get("/api/programs")
def list_programs():
    with db() as conn:
        return rows_to_list(conn.execute("""
            SELECT p.*, o.name as org_name,
                   c.first_name || ' ' || COALESCE(c.last_name, '') as contact_name
            FROM programs p
            LEFT JOIN organizations o ON p.organization_id = o.id
            LEFT JOIN contacts c ON p.primary_contact_id = c.id
            ORDER BY p.status, p.name
        """).fetchall())


# ==================== STATS ====================

@app.get("/api/stats")
def get_stats():
    with db() as conn:
        c = conn.cursor()
        stats = {}
        c.execute("SELECT COUNT(*) FROM contacts")
        stats["total_contacts"] = c.fetchone()[0]
        c.execute("SELECT category, COUNT(*) FROM contacts GROUP BY category")
        stats["by_category"] = {r[0]: r[1] for r in c.fetchall()}
        c.execute("SELECT status, COUNT(*) FROM contacts GROUP BY status")
        stats["by_status"] = {r[0]: r[1] for r in c.fetchall()}
        c.execute("SELECT COUNT(*) FROM contacts WHERE category='investor' AND status NOT IN ('passed','cold')")
        stats["active_investors"] = c.fetchone()[0]
        c.execute("SELECT SUM(probability) FROM deals")
        stats["pipeline_probability"] = c.fetchone()[0] or 0
        c.execute("SELECT COUNT(*) FROM deals WHERE stage NOT IN ('passed','dead','closed')")
        stats["active_deals"] = c.fetchone()[0]
        c.execute("SELECT COUNT(*) FROM interactions")
        stats["total_interactions"] = c.fetchone()[0]
        c.execute("SELECT COUNT(*) FROM organizations")
        stats["total_organizations"] = c.fetchone()[0]
        return stats


# ==================== STATIC FRONTEND ====================

FRONTEND_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "frontend", "dist")

if os.path.isdir(FRONTEND_DIR):
    app.mount("/assets", StaticFiles(directory=os.path.join(FRONTEND_DIR, "assets")), name="assets")

    @app.get("/{full_path:path}")
    def serve_frontend(full_path: str):
        file_path = os.path.join(FRONTEND_DIR, full_path)
        if os.path.isfile(file_path):
            return FileResponse(file_path)
        return FileResponse(os.path.join(FRONTEND_DIR, "index.html"))


if __name__ == "__main__":
    import uvicorn
    port = int(os.environ.get("PORT", 8080))
    uvicorn.run(app, host="0.0.0.0", port=port)
